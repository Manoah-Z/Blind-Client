# Fake ClickGUI (Fabric 1.21.11)

Mod Fabric **100% cosmétique** : il reproduit l'interface de la capture d'écran
(panneaux Combat / Misc / Donut / Render / Client, avec liste de "modules" et
petit indicateur rond à droite) mais **aucun module ne fait quoi que ce soit**.
Cliquer sur une ligne change juste la couleur du texte et du point — c'est
uniquement un menu factice, pas un cheat fonctionnel (pas de reach, pas
d'ESP, pas d'autoclick réel, etc.).

## Ouvrir le menu

Par défaut : touche **Shift droit**. Rebindable dans
`Options > Contrôles > Touches > Fake ClickGUI`.

## Compiler le mod

Prérequis : JDK 21.

```bash
cd fakeclickgui
gradle wrapper   # génère gradlew/gradlew.bat (une seule fois, nécessite Gradle installé)
./gradlew build
```

*(Le zip ne contient pas le wrapper Gradle binaire. Si vous ouvrez le
dossier directement dans IntelliJ IDEA, il génère et configure tout ça
automatiquement — c'est la méthode la plus simple.)*

Le fichier `.jar` sera dans `build/libs/fakeclickgui-1.0.0.jar`. Copiez-le
dans le dossier `mods` de votre installation Fabric (Fabric Loader +
Fabric API installés, Minecraft 1.21.11).

## ⚠️ À propos de la version 1.21.11

Le fichier `gradle.properties` contient déjà des valeurs vérifiées pour
1.21.11 (yarn `1.21.11+build.1`, Fabric API `0.141.3+1.21.11`, Fabric
Loader `0.18.4`). C'est une version très récente du jeu — si Gradle
échoue avec une erreur du style "mapping introuvable" ou "impossible de
résoudre la dépendance", ces numéros ont probablement changé entre-temps.
Dans ce cas :

1. Allez sur https://fabricmc.net/develop/template/ (générateur officiel).
2. Sélectionnez Minecraft **1.21.11**.
3. Copiez les valeurs générées (`yarn_mappings`, `loader_version`,
   `fabric_version`) dans le `gradle.properties` de ce projet — le code
   Java n'a pas besoin de changer.

Si vous préférez une version 100% éprouvée sans risque d'erreur, vous
pouvez aussi simplement remplacer, dans `gradle.properties` :

```properties
minecraft_version=1.21.1
yarn_mappings=1.21.1+build.3
loader_version=0.16.9
fabric_version=0.106.0+1.21.1
```

et changer `"minecraft": "~1.21.11"` en `"minecraft": "~1.21.1"` dans
`src/main/resources/fabric.mod.json`. Le reste du mod fonctionne à
l'identique sur 1.21.1.

## Structure

```
src/main/java/com/fakegui/clickgui/
├── FakeClickGuiClient.java     # point d'entrée client, enregistre la touche
└── gui/
    ├── ClickGuiScreen.java     # rendu des 5 panneaux + gestion des clics
    ├── Category.java           # un panneau (titre + liste de modules)
    └── Module.java             # une ligne togglable (juste un booléen)
```

Pour ajouter/renommer des modules, éditez la méthode `buildCategories()`
dans `ClickGuiScreen.java`.
