package com.fakegui.clickgui.hud;

/**
 * Estimates server TPS the same way most clients do: the server sends a
 * world-time update packet every 20 ticks, so on a perfect 20 TPS server
 * those packets arrive exactly 1 second apart. If they arrive 2 seconds
 * apart, the server is running at 10 TPS, and so on.
 */
public final class TpsTracker {

    private static final int SAMPLE_COUNT = 10;
    private static final float[] samples = new float[SAMPLE_COUNT];
    private static int sampleIndex = 0;
    private static int sampleFilled = 0;
    private static long lastUpdateNanos = -1;

    private TpsTracker() {
    }

    /** Called (via mixin) every time a world-time update packet arrives. */
    public static void onTimeUpdate() {
        long now = System.nanoTime();
        if (lastUpdateNanos > 0) {
            float seconds = (now - lastUpdateNanos) / 1_000_000_000f;
            if (seconds > 0) {
                float tps = Math.min(20f, Math.max(0f, 20f / seconds));
                samples[sampleIndex] = tps;
                sampleIndex = (sampleIndex + 1) % SAMPLE_COUNT;
                if (sampleFilled < SAMPLE_COUNT) sampleFilled++;
            }
        }
        lastUpdateNanos = now;
    }

    public static void reset() {
        sampleIndex = 0;
        sampleFilled = 0;
        lastUpdateNanos = -1;
    }

    /** @return averaged TPS, or -1 if no data yet. */
    public static float getTps() {
        if (sampleFilled == 0) {
            return -1f;
        }
        float sum = 0;
        for (int i = 0; i < sampleFilled; i++) sum += samples[i];
        return sum / sampleFilled;
    }
}
