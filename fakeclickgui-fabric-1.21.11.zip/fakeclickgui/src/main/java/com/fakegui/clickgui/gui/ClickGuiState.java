package com.fakegui.clickgui.gui;

import java.util.ArrayList;
import java.util.List;

/**
 * Builds the category/module list exactly once and hands the same
 * instances back every time the GUI is opened, so toggle state,
 * collapsed/expanded state, keybinds, and dragged panel positions all
 * survive closing and reopening the menu (for as long as the game keeps
 * running).
 */
public final class ClickGuiState {

    private static final int PANEL_X = 20;
    private static final int PANEL_Y = 20;
    private static final int PANEL_WIDTH = 148;
    private static final int PANEL_GAP = 14;

    private static List<Category> categories;
    private static Category searchPanel;

    private ClickGuiState() {
    }

    public static List<Category> getCategories() {
        if (categories == null) {
            categories = build();
        }
        return categories;
    }

    public static Category getSearchPanel() {
        if (searchPanel == null) {
            searchPanel = new Category("Search", new ArrayList<>());
            int x = PANEL_X + getCategories().size() * (PANEL_WIDTH + PANEL_GAP);
            searchPanel.setX(x);
            searchPanel.setY(PANEL_Y);
        }
        return searchPanel;
    }

    private static List<Category> build() {
        List<Category> list = new ArrayList<>();

        list.add(new Category("Combat", modules(
                m("Aim Assist", "Nudges your aim toward nearby targets automatically."),
                m("Anchor Macro", "Automates placing and breaking anchors for fall-damage combos."),
                m("Auto Double Hand", "Automatically duplicates your held item into the offhand."),
                m("Auto Crystal", "Automatically places and detonates end crystals near the target."),
                m("Auto Hit Crystal", "Automatically swings at nearby end crystals to break them."),
                m("Auto Inv Totem", "Keeps a totem of undying in your offhand automatically."),
                m("Auto Jump Reset", "Resets fall/jump state automatically for smoother movement combos."),
                m("Auto Totem", "Automatically re-equips a totem of undying when one is consumed."),
                m("Crystal Optimizer", "Calculates optimal crystal placement for maximum damage."),
                m("Double Anchor", "Places two anchors in sequence for stronger combo damage."),
                m("Elytra Swap", "Automatically swaps to an elytra when falling."),
                m("Hitbox", "Expands the perceived hitbox of nearby entities."),
                m("Hover Totem", "Keeps a totem selected in hand without consuming inventory slots."),
                m("Totem Offhand", "Automatically moves totems into the offhand slot."),
                m("Mace Swap", "Automatically swaps to a mace weapon during combat."),
                m("Spear Swap", "Automatically swaps to a spear-type weapon during combat."),
                m("No Hit Delay", "Removes the attack cooldown between hits."),
                m("Shield Breaker", "Times attacks to break through an opponent's shield."),
                m("Static Hitboxes", "Keeps hitboxes fixed in place rather than following movement."),
                m("Trigger Bot", "Automatically attacks whenever an entity enters your crosshair."),
                m("Mace Bomber", "Chains mace attacks with knockback for aerial combos.")
        )));

        list.add(new Category("Misc", modules(
                m("Auto Clicker", "Automatically repeats clicks at a set rate while held."),
                m("Auto Eat", "Automatically eats food when your hunger gets low."),
                m("Auto Firework", "Automatically uses fireworks while flying with an elytra."),
                m("Auto Log", "Disconnects automatically when your health drops below a threshold."),
                m("Auto Loot", "Automatically picks up nearby dropped items."),
                m("Auto Mine", "Automatically mines blocks in front of you."),
                m("Auto Tool", "Automatically switches to the best tool for the block you're breaking."),
                m("Auto TPA", "Automatically accepts teleport requests from other players."),
                m("Coord Snapper", "Records and displays coordinates of nearby players."),
                m("Elytra Glide", "Improves elytra glide efficiency automatically."),
                m("Fast Place", "Speeds up block placement rate."),
                m("Freecam", "Detaches the camera from your player to explore freely."),
                m("Key Pearl", "Throws an ender pearl automatically with a keybind."),
                m("Key Wind Charge", "Uses a wind charge automatically with a keybind."),
                m("Name Protect", "Hides your real username on screen for streaming/screenshots."),
                m("Sprint", "Keeps your character sprinting automatically."),
                m("Skin Protect", "Hides your real skin on screen for streaming/screenshots."),
                m("Auto Reconnect", "Automatically reconnects to the server if you get disconnected.")
        )));

        list.add(new Category("Donut", modules(
                m("Anti Trap", "Warns you when you're about to trigger a trap."),
                m("Auction Sniper", "Watches auction house listings for underpriced items."),
                m("Auto Sell", "Automatically sells items to a shop when your inventory fills up."),
                m("Auto Spawner Sell", "Automatically sells spawner drops at a shop."),
                m("Item Dropper", "Automatically drops selected items from your inventory."),
                m("Netherite Finder", "Highlights the direction of nearby netherite ore."),
                m("RTP Base Finder", "Scans random-teleport spawns for nearby player bases."),
                m("Auto Shulker Buy", "Automatically purchases shulker boxes from a shop."),
                m("Tunnel Base Finder", "Detects hidden tunnels leading to player bases."),
                m("Fake Stats", "Displays altered statistics instead of your real ones."),
                m("Spawner Protect", "Alerts you when someone approaches your spawner."),
                m("Chunk Finder", "Highlights loaded chunk borders on screen."),
                m("Sus Chunk Finder", "Flags chunks with unusual terrain edits nearby.")
        )));

        list.add(new Category("Basefinding", modules(
                m("Seed Chunk Finder", "Locates chunks matching known seed-based structure patterns."),
                m("Hole ESP", "Highlights obby-hole style excavations through terrain."),
                m("Light Finder", "Flags unnatural light sources hidden underground."),
                m("Jungle Finder", "Points toward the nearest jungle biome."),
                m("Suspicious ESP", "Flags terrain that looks artificially modified.")
        )));

        list.add(new Category("Render", modules(
                m("Ore Sim", "Simulates and displays likely ore distribution nearby."),
                m("Fullbright", "Maximizes in-game brightness regardless of lighting."),
                m("SwingSpeed", "Displays your current attack swing speed."),
                m("Jump Circles", "Draws a ring on the ground showing jump landing range."),
                m("Hud", "Displays extra information like coordinates and FPS on screen."),
                m("Player ESP", "Shows the outline of players through walls."),
                m("Storage ESP", "Shows the outline of chests and storage through walls."),
                m("Block ESP", "Shows the outline of specific blocks through walls."),
                m("Target Hud", "Displays health and info about your current combat target."),
                m("Realhitbox", "Displays the true hitbox size of nearby entities."),
                m("Free Look", "Lets you look around independently while moving normally.")
        )));

        list.add(new Category("Client", modules(
                m("Blind+", "Enables enhanced client-side network and rendering optimizations."),
                withText(m("Chat Macro", "When enabled, its keybind sends the message below in chat. Start it with / to run a command."), "gg"),
                m("Radio", "Streams music inside the game through an in-client player."),
                m("Friends", "Manages a list of trusted players across servers."),
                m("Discord Presence", "Shows your current activity on your Discord profile.")
        )));

        // Default staggered layout, same as the original screenshot.
        int x = PANEL_X;
        for (Category category : list) {
            category.setX(x);
            category.setY(PANEL_Y);
            x += PANEL_WIDTH + PANEL_GAP;
        }

        return list;
    }

    private static Module m(String name, String description) {
        return new Module(name, description);
    }

    private static Module withText(Module module, String defaultText) {
        module.setTextSetting(defaultText);
        return module;
    }

    private static List<Module> modules(Module... mods) {
        List<Module> list = new ArrayList<>();
        for (Module mod : mods) list.add(mod);
        return list;
    }
}
