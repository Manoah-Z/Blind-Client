package com.fakegui.clickgui;

import com.fakegui.clickgui.gui.ClickGuiScreen;
import com.fakegui.clickgui.gui.ClickGuiState;
import com.fakegui.clickgui.gui.Module;
import com.fakegui.clickgui.hud.HudRenderer;
import com.fakegui.clickgui.hud.TpsTracker;
import com.fakegui.clickgui.reconnect.ReconnectHandler;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class FakeClickGuiClient implements ClientModInitializer {

    private static KeyBinding openGuiKey;

    @Override
    public void onInitializeClient() {
        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of("fakeclickgui", "main"));

        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.fakeclickgui.open",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                category
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGuiKey.wasPressed()) {
                if (client.currentScreen == null) {
                    ClickGuiScreen.open();
                }
            }

            applyFullbright(client);
            applySprint(client);
            pollModuleBinds(client);
            ReconnectHandler.tick(client);
            HudRenderer.tick(client);
        });

        HudRenderCallback.EVENT.register(this::renderHud);

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> TpsTracker.reset());

        // Disconnect screen buttons + Auto Reconnect, see reconnect/ReconnectHandler.
        ReconnectHandler.register();
    }

    /** Meteor-style HUD, see hud/HudRenderer. */
    private void renderHud(net.minecraft.client.gui.DrawContext context, Object tickCounter) {
        Module hud = findModule("Hud");
        HudRenderer.render(context, hud != null && hud.isEnabled());
    }

    private boolean nightVisionApplied = false;

    /**
     * Fullbright via a client-side Night Vision effect.
     *
     * The effect is only added to the local client player object (nothing
     * is sent to the server), so it's purely visual. We refresh it every
     * tick with a long duration: vanilla Night Vision starts "flickering"
     * when fewer than 200 ticks remain, so keeping it well above that
     * avoids any blinking. When the module is turned off we remove it,
     * but only if we're the ones who added it (so a real Night Vision
     * potion you drank isn't wiped).
     */
    private void applyFullbright(MinecraftClient client) {
        Module fullbright = findModule("Fullbright");
        ClientPlayerEntity player = client.player;
        if (fullbright == null || player == null) {
            nightVisionApplied = false;
            return;
        }

        if (fullbright.isEnabled()) {
            StatusEffectInstance current = player.getStatusEffect(StatusEffects.NIGHT_VISION);
            if (current == null || (nightVisionApplied && current.getDuration() < 400)) {
                player.addStatusEffect(new StatusEffectInstance(
                        StatusEffects.NIGHT_VISION,
                        1000,   // duration in ticks (refreshed long before it runs low)
                        0,      // amplifier (level I)
                        false,  // ambient
                        false,  // no particles
                        false   // no HUD icon
                ));
                nightVisionApplied = true;
            }
        } else if (nightVisionApplied) {
            player.removeStatusEffect(StatusEffects.NIGHT_VISION);
            nightVisionApplied = false;
        }
    }

    private Module findModule(String name) {
        for (var category : ClickGuiState.getCategories()) {
            for (Module module : category.getModules()) {
                if (module.getName().equals(name)) {
                    return module;
                }
            }
        }
        return null;
    }

    /**
     * Lets a module be toggled with its assigned key while the GUI is
     * closed. Only runs when no screen is open at all, so it never
     * conflicts with typing in the GUI's own search box.
     */
    private void pollModuleBinds(MinecraftClient client) {
        if (client.currentScreen != null || client.getWindow() == null) {
            return;
        }
        long windowHandle = client.getWindow().getHandle();

        for (var category : ClickGuiState.getCategories()) {
            for (Module module : category.getModules()) {
                int bind = module.getKeyBind();
                if (bind == -1) {
                    continue;
                }
                boolean held = module.isBindMouse()
                        ? GLFW.glfwGetMouseButton(windowHandle, bind) == GLFW.GLFW_PRESS
                        : GLFW.glfwGetKey(windowHandle, bind) == GLFW.GLFW_PRESS;

                // Trigger on press by default, or on release if the module's
                // "Toggle on bind release" option is enabled.
                boolean triggered = module.isToggleOnRelease()
                        ? (!held && module.isHeldLastTick())
                        : (held && !module.isHeldLastTick());

                if (triggered) {
                    if (module.hasTextSetting() && module.getName().equals("Chat Macro")) {
                        // Chat Macro: while enabled, its key sends the message
                        // instead of toggling the module off.
                        if (module.isEnabled()) {
                            sendChatMacro(client, module.getTextSetting());
                        }
                    } else {
                        module.toggle();
                        if (module.isChatFeedback()) {
                            sendToggleFeedback(client, module);
                        }
                    }
                }
                module.setHeldLastTick(held);
            }
        }
    }

    private boolean sprintPressedByUs = false;

    /**
     * Sprint: virtually holds the vanilla sprint key while enabled, so every
     * vanilla sprint rule still applies (no sprint when too hungry, walking
     * backwards, etc.). Released once when the module is turned off.
     */
    private void applySprint(MinecraftClient client) {
        Module sprint = findModule("Sprint");
        if (sprint == null || client.player == null || client.options == null) {
            return;
        }
        KeyBinding sprintKey = client.options.sprintKey;
        if (sprint.isEnabled()) {
            if (!sprintKey.isPressed()) {
                sprintKey.setPressed(true);
            }
            sprintPressedByUs = true;
        } else if (sprintPressedByUs) {
            sprintKey.setPressed(false);
            sprintPressedByUs = false;
        }
    }

    /** Sends the Chat Macro text: as a command if it starts with "/", else as chat. */
    private void sendChatMacro(MinecraftClient client, String message) {
        if (client.player == null || client.getNetworkHandler() == null) {
            return;
        }
        String text = message == null ? "" : message.trim();
        if (text.isEmpty()) {
            return;
        }
        if (text.startsWith("/")) {
            client.getNetworkHandler().sendChatCommand(text.substring(1));
        } else {
            client.getNetworkHandler().sendChatMessage(text);
        }
    }

    /** Local-only chat line, e.g. "[Blind Client] Fullbright ON". Never sent to the server. */
    private void sendToggleFeedback(MinecraftClient client, Module module) {
        if (client.inGameHud == null) {
            return;
        }
        Text message = Text.literal("[Blind Client] ").formatted(Formatting.GOLD)
                .append(Text.literal(module.getName() + " ").formatted(Formatting.WHITE))
                .append(module.isEnabled()
                        ? Text.literal("ON").formatted(Formatting.GREEN)
                        : Text.literal("OFF").formatted(Formatting.RED));
        client.inGameHud.getChatHud().addMessage(message);
    }
}
