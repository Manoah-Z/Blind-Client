package com.fakegui.clickgui.gui;

import net.minecraft.text.Style;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

/**
 * Blind Client theme, shared by the ClickGUI and the module settings screen.
 * To try another color scheme, only the ACCENT values below need changing.
 */
public final class Theme {

    // ---- Accent (orange) ---------------------------------------------
    public static final int ACCENT = 0xFFE8450E;        // headers, toggles, bars
    public static final int ACCENT_LIGHT = 0xFFFF8A5C;  // text of enabled modules

    // ---- Neutrals ----------------------------------------------------
    public static final int PANEL_BG = 0xE6141520;
    public static final int HEADER_BG = 0xFF1B1D29;
    public static final int FIELD_BG = 0xFF1B1D29;
    public static final int FIELD_BG_FOCUSED = 0xFF262B3A;
    public static final int BORDER = 0x552F3140;
    public static final int FIELD_BORDER = 0xFF3A3E4C;
    public static final int TEXT = 0xFFC9CDD6;
    public static final int TEXT_WHITE = 0xFFFFFFFF;
    public static final int TEXT_DIM = 0xFF6B6F7A;
    public static final int SEPARATOR = 0xFF3A3E4C;

    public static final Identifier FONT_ID = Identifier.of("fakeclickgui", "clickgui");

    private Theme() {
    }

    public static Text styled(String s) {
        return Text.literal(s).setStyle(Style.EMPTY.withFont(new StyleSpriteSource.Font(FONT_ID)));
    }

    /** Human-readable name of a module's bind ("None", "G", "MOUSE 4"...). */
    public static String bindName(Module module) {
        if (module.getKeyBind() == -1) {
            return "None";
        }
        if (module.isBindMouse()) {
            return mouseButtonName(module.getKeyBind());
        }
        return keyName(module.getKeyBind());
    }

    public static String mouseButtonName(int button) {
        return switch (button) {
            case GLFW.GLFW_MOUSE_BUTTON_LEFT -> "LMB";
            case GLFW.GLFW_MOUSE_BUTTON_RIGHT -> "RMB";
            case GLFW.GLFW_MOUSE_BUTTON_MIDDLE -> "MMB";
            default -> "MOUSE " + (button + 1);
        };
    }

    public static String keyName(int keyCode) {
        return switch (keyCode) {
            case GLFW.GLFW_KEY_SPACE -> "SPACE";
            case GLFW.GLFW_KEY_LEFT_SHIFT -> "L-SHIFT";
            case GLFW.GLFW_KEY_RIGHT_SHIFT -> "R-SHIFT";
            case GLFW.GLFW_KEY_LEFT_CONTROL -> "L-CTRL";
            case GLFW.GLFW_KEY_RIGHT_CONTROL -> "R-CTRL";
            case GLFW.GLFW_KEY_LEFT_ALT -> "L-ALT";
            case GLFW.GLFW_KEY_RIGHT_ALT -> "R-ALT";
            case GLFW.GLFW_KEY_TAB -> "TAB";
            case GLFW.GLFW_KEY_CAPS_LOCK -> "CAPS";
            case GLFW.GLFW_KEY_ENTER, GLFW.GLFW_KEY_KP_ENTER -> "ENTER";
            case GLFW.GLFW_KEY_UP -> "UP";
            case GLFW.GLFW_KEY_DOWN -> "DOWN";
            case GLFW.GLFW_KEY_LEFT -> "LEFT";
            case GLFW.GLFW_KEY_RIGHT -> "RIGHT";
            default -> {
                String glfwName = GLFW.glfwGetKeyName(keyCode, 0);
                yield glfwName != null ? glfwName.toUpperCase() : "KEY " + keyCode;
            }
        };
    }
}
