package com.fakegui.clickgui.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * Per-module settings screen (opened with right-click in the ClickGUI).
 * The ClickGUI is hidden while this is open; Escape goes back to it.
 *
 * Layout, top to bottom:
 *   [ Module Name ]                  (accent header bar)
 *   description
 *   ---- General ----                (only for modules with a text setting)
 *   Message: [ text field ]
 *   ---- Bind ----
 *   Bind: [ None ]                   (click, then press a key or mouse button)
 *   Toggle on bind release: [ ]
 *   Chat Feedback: [x]
 *   ----------------
 *   Active: [ ]
 */
public class ModuleScreen extends Screen {

    private static final double REFERENCE_GUI_SCALE = 2.0;

    private static final int WIDTH = 300;
    private static final int HEADER_HEIGHT = 18;
    private static final int PADDING = 6;
    private static final int LINE_HEIGHT = 10;
    private static final int ROW_HEIGHT = 18;
    private static final int BOX = 11;          // checkbox size
    private static final int FIELD_HEIGHT = 13;

    private final Module module;
    private final Screen parent;

    private boolean listeningForBind = false;
    private boolean editingText = false;

    // Hit-boxes, recomputed on every render (design-space coordinates).
    private final int[] bindButton = new int[4];
    private final int[] releaseBox = new int[4];
    private final int[] feedbackBox = new int[4];
    private final int[] activeBox = new int[4];
    private final int[] textField = new int[4];
    private boolean hasTextField = false;

    public ModuleScreen(Module module, Screen parent) {
        super(Text.literal(module.getName()));
        this.module = module;
        this.parent = parent;
    }

    private double getUiScale() {
        double current = MinecraftClient.getInstance().getWindow().getScaleFactor();
        return current <= 0 ? 1.0 : REFERENCE_GUI_SCALE / current;
    }

    // ------------------------------------------------------------------
    // Rendering
    // ------------------------------------------------------------------

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        double uiScale = getUiScale();
        int mx = (int) Math.round(mouseX / uiScale);
        int my = (int) Math.round(mouseY / uiScale);
        int designWidth = (int) Math.round(this.width / uiScale);
        int designHeight = (int) Math.round(this.height / uiScale);

        context.getMatrices().pushMatrix();
        context.getMatrices().scale((float) uiScale, (float) uiScale);

        List<String> descLines = wrap(module.getDescription(), WIDTH - PADDING * 2);
        int totalHeight = computeHeight(descLines.size());
        int x0 = (designWidth - WIDTH) / 2;
        int y0 = Math.max(10, (designHeight - totalHeight) / 2);

        // Panel + header
        context.fill(x0, y0, x0 + WIDTH, y0 + totalHeight, Theme.PANEL_BG);
        context.fill(x0, y0, x0 + WIDTH, y0 + HEADER_HEIGHT, Theme.ACCENT);
        int titleW = this.textRenderer.getWidth(Theme.styled(module.getName()));
        context.drawTextWithShadow(this.textRenderer, Theme.styled(module.getName()),
                x0 + (WIDTH - titleW) / 2, y0 + 5, Theme.TEXT_WHITE);

        int y = y0 + HEADER_HEIGHT + PADDING;
        for (String line : descLines) {
            context.drawTextWithShadow(this.textRenderer, Theme.styled(line), x0 + PADDING, y, Theme.TEXT);
            y += LINE_HEIGHT;
        }
        y += 4;

        // ---- General (text setting) ----
        hasTextField = module.hasTextSetting();
        if (hasTextField) {
            y = drawSection(context, "General", x0, y);
            int labelW = drawLabel(context, "Message:", x0, y);
            int fx = x0 + PADDING + labelW + 6;
            setRect(textField, fx, y + (ROW_HEIGHT - FIELD_HEIGHT) / 2 - 2, x0 + WIDTH - PADDING - fx, FIELD_HEIGHT);
            drawTextField(context);
            y += ROW_HEIGHT;
        }

        // ---- Bind ----
        y = drawSection(context, "Bind", x0, y);

        int labelW = drawLabel(context, "Bind:", x0, y);
        String bindText = listeningForBind ? "Press a key..." : Theme.bindName(module);
        int btnW = this.textRenderer.getWidth(Theme.styled(bindText)) + 10;
        setRect(bindButton, x0 + PADDING + labelW + 6, y + (ROW_HEIGHT - FIELD_HEIGHT) / 2 - 2, btnW, FIELD_HEIGHT);
        boolean bindHovered = inside(bindButton, mx, my);
        drawField(context, bindButton, listeningForBind || bindHovered);
        context.drawTextWithShadow(this.textRenderer, Theme.styled(bindText),
                bindButton[0] + 5, bindButton[1] + 3, listeningForBind ? Theme.ACCENT_LIGHT : Theme.TEXT_WHITE);
        y += ROW_HEIGHT;

        labelW = drawLabel(context, "Toggle on bind release:", x0, y);
        setRect(releaseBox, x0 + PADDING + labelW + 6, y + (ROW_HEIGHT - BOX) / 2 - 2, BOX, BOX);
        drawCheckbox(context, releaseBox, module.isToggleOnRelease(), inside(releaseBox, mx, my));
        y += ROW_HEIGHT;

        labelW = drawLabel(context, "Chat Feedback:", x0, y);
        setRect(feedbackBox, x0 + PADDING + labelW + 6, y + (ROW_HEIGHT - BOX) / 2 - 2, BOX, BOX);
        drawCheckbox(context, feedbackBox, module.isChatFeedback(), inside(feedbackBox, mx, my));
        y += ROW_HEIGHT;

        // ---- Active ----
        context.fill(x0 + PADDING, y + 1, x0 + WIDTH - PADDING, y + 2, Theme.SEPARATOR);
        y += 5;
        labelW = drawLabel(context, "Active:", x0, y);
        setRect(activeBox, x0 + PADDING + labelW + 6, y + (ROW_HEIGHT - BOX) / 2 - 2, BOX, BOX);
        drawCheckbox(context, activeBox, module.isEnabled(), inside(activeBox, mx, my));

        context.getMatrices().popMatrix();
        super.render(context, mouseX, mouseY, delta);
    }

    private int computeHeight(int descLineCount) {
        int h = HEADER_HEIGHT + PADDING + descLineCount * LINE_HEIGHT + 4;
        if (module.hasTextSetting()) {
            h += 14 + ROW_HEIGHT;              // section + message row
        }
        h += 14 + ROW_HEIGHT * 3;               // bind section + 3 rows
        h += 5 + ROW_HEIGHT;                    // separator + active row
        return h + 2;
    }

    /** Section title centered on a horizontal line, like "---- Bind ----". */
    private int drawSection(DrawContext context, String title, int x0, int y) {
        int textW = this.textRenderer.getWidth(Theme.styled(title));
        int centerX = x0 + WIDTH / 2;
        int lineY = y + 4;
        context.fill(x0 + PADDING, lineY, centerX - textW / 2 - 4, lineY + 1, Theme.SEPARATOR);
        context.fill(centerX + textW / 2 + 4, lineY, x0 + WIDTH - PADDING, lineY + 1, Theme.SEPARATOR);
        context.drawTextWithShadow(this.textRenderer, Theme.styled(title), centerX - textW / 2, y, Theme.TEXT_WHITE);
        return y + 14;
    }

    private int drawLabel(DrawContext context, String label, int x0, int y) {
        context.drawTextWithShadow(this.textRenderer, Theme.styled(label), x0 + PADDING, y + 3, Theme.TEXT);
        return this.textRenderer.getWidth(Theme.styled(label));
    }

    private void drawField(DrawContext context, int[] r, boolean highlighted) {
        context.fill(r[0], r[1], r[0] + r[2], r[1] + r[3], highlighted ? Theme.FIELD_BG_FOCUSED : Theme.FIELD_BG);
        context.drawStrokedRectangle(r[0], r[1], r[2], r[3], highlighted ? Theme.ACCENT : Theme.FIELD_BORDER);
    }

    private void drawCheckbox(DrawContext context, int[] r, boolean checked, boolean hovered) {
        drawField(context, r, hovered);
        if (checked) {
            context.fill(r[0] + 2, r[1] + 2, r[0] + r[2] - 2, r[1] + r[3] - 2, Theme.ACCENT);
        }
    }

    private void drawTextField(DrawContext context) {
        drawField(context, textField, editingText);
        String value = module.getTextSetting();
        int maxW = textField[2] - 8;
        String shown = value;
        while (!shown.isEmpty() && this.textRenderer.getWidth(Theme.styled(shown)) > maxW) {
            shown = shown.substring(1);
        }
        context.drawTextWithShadow(this.textRenderer, Theme.styled(shown),
                textField[0] + 4, textField[1] + 3, Theme.TEXT_WHITE);
        if (editingText) {
            int caretX = textField[0] + 4 + this.textRenderer.getWidth(Theme.styled(shown));
            context.fill(caretX + 1, textField[1] + 2, caretX + 2, textField[1] + textField[3] - 2, Theme.TEXT_WHITE);
        }
    }

    private List<String> wrap(String text, int maxWidth) {
        List<String> lines = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String word : text.split(" ")) {
            String candidate = line.isEmpty() ? word : line + " " + word;
            if (this.textRenderer.getWidth(Theme.styled(candidate)) > maxWidth && !line.isEmpty()) {
                lines.add(line.toString());
                line = new StringBuilder(word);
            } else {
                line = new StringBuilder(candidate);
            }
        }
        if (!line.isEmpty()) {
            lines.add(line.toString());
        }
        return lines;
    }

    private static void setRect(int[] r, int x, int y, int w, int h) {
        r[0] = x;
        r[1] = y;
        r[2] = w;
        r[3] = h;
    }

    private static boolean inside(int[] r, double x, double y) {
        return x >= r[0] && x <= r[0] + r[2] && y >= r[1] && y <= r[1] + r[3];
    }

    // ------------------------------------------------------------------
    // Input
    // ------------------------------------------------------------------

    @Override
    public boolean mouseClicked(Click click, boolean doubleClick) {
        double uiScale = getUiScale();
        double mx = click.x() / uiScale;
        double my = click.y() / uiScale;
        int button = click.button();

        if (listeningForBind) {
            if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
                // Left click cancels listening (left click itself can't be bound,
                // otherwise every attack would toggle the module).
                listeningForBind = false;
            } else {
                module.setMouseBind(button);
                listeningForBind = false;
            }
            return true;
        }

        if (button != GLFW.GLFW_MOUSE_BUTTON_LEFT) {
            return super.mouseClicked(click, doubleClick);
        }

        editingText = false;

        if (inside(bindButton, mx, my)) {
            listeningForBind = true;
            return true;
        }
        if (hasTextField && inside(textField, mx, my)) {
            editingText = true;
            return true;
        }
        if (inside(releaseBox, mx, my)) {
            module.setToggleOnRelease(!module.isToggleOnRelease());
            return true;
        }
        if (inside(feedbackBox, mx, my)) {
            module.setChatFeedback(!module.isChatFeedback());
            return true;
        }
        if (inside(activeBox, mx, my)) {
            module.toggle();
            return true;
        }
        return super.mouseClicked(click, doubleClick);
    }

    @Override
    public boolean charTyped(CharInput input) {
        if (editingText) {
            int codepoint = input.codepoint();
            String current = module.getTextSetting();
            if (codepoint >= 32 && codepoint != 127 && current.length() < 256) {
                module.setTextSetting(current + new String(Character.toChars(codepoint)));
            }
            return true;
        }
        return super.charTyped(input);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();

        if (listeningForBind) {
            if (key == GLFW.GLFW_KEY_ESCAPE) {
                module.clearBind();
            } else {
                module.setKeyBind(key);
            }
            listeningForBind = false;
            return true;
        }

        if (editingText) {
            String current = module.getTextSetting();
            if (key == GLFW.GLFW_KEY_BACKSPACE && !current.isEmpty()) {
                module.setTextSetting(current.substring(0, current.length() - 1));
            } else if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
                editingText = false;
            }
            return true;
        }
        return super.keyPressed(input);
    }

    /**
     * Escape handling. Same pattern as the ClickGUI (confirmed working):
     * Escape while listening for a bind = set it to None; while typing =
     * stop typing; otherwise go back to the ClickGUI instead of closing
     * everything.
     */
    @Override
    public void close() {
        if (listeningForBind) {
            module.clearBind();
            listeningForBind = false;
            return;
        }
        if (editingText) {
            editingText = false;
            return;
        }
        MinecraftClient.getInstance().setScreen(parent);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
