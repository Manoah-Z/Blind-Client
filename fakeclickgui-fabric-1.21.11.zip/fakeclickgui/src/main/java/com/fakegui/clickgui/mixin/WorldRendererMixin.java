package com.fakegui.clickgui.mixin;

import com.fakegui.clickgui.gui.ClickGuiState;
import com.fakegui.clickgui.gui.Module;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockRenderView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Real Fullbright.
 *
 * Driving the vanilla "gamma" option (see FakeClickGuiClient.applyFullbright)
 * turned out to have little to no visible effect: the game's own brightness
 * slider appears to internally clamp/limit that value before it ever
 * affects rendering, no matter how extreme a number we feed it.
 *
 * This mixin instead overrides WorldRenderer.getLightmapCoordinates, the
 * method every rendered block/entity calls to find out "how lit is this
 * position", and simply forces it to report the maximum possible light
 * (15 sky, 15 block) whenever Fullbright is on. This is the standard,
 * reliable technique real fullbright/x-ray-adjacent mods use, since it
 * works at the world-light level rather than fighting the options system.
 */
@Mixin(WorldRenderer.class)
public class WorldRendererMixin {

    @Inject(
            method = "getLightmapCoordinates(Lnet/minecraft/world/BlockRenderView;Lnet/minecraft/util/math/BlockPos;)I",
            at = @At("RETURN"),
            cancellable = true
    )
    private static void fakeclickgui$fullbrightByPos(BlockRenderView world, BlockPos pos,
                                                       CallbackInfoReturnable<Integer> cir) {
        if (isFullbrightEnabled()) {
            cir.setReturnValue(LightmapTextureManager.pack(15, 15));
        }
    }

    private static boolean isFullbrightEnabled() {
        for (var category : ClickGuiState.getCategories()) {
            for (Module module : category.getModules()) {
                if (module.getName().equals("Fullbright")) {
                    return module.isEnabled();
                }
            }
        }
        return false;
    }
}
