package com.fakegui.clickgui.hud;

import com.fakegui.clickgui.gui.Category;
import com.fakegui.clickgui.gui.ClickGuiState;
import com.fakegui.clickgui.gui.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Style;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

/**
 * Meteor-style HUD: small white text in the mod's custom font.
 * Top-left: client name, FPS, TPS, Ping, Speed.
 * Top-right: list of currently enabled modules, longest name first.
 */
public final class HudRenderer {

    private static final Identifier FONT_ID = Identifier.of("fakeclickgui", "clickgui");
    private static final int WHITE = 0xFFFFFFFF;

    // Text size relative to normal Minecraft text. Lower = smaller.
    private static final float TEXT_SCALE = 0.6f;
    // Designed to look right at GUI Scale 2, compensated for other scales
    // (same principle as the ClickGUI) so it never becomes huge.
    private static final double REFERENCE_GUI_SCALE = 2.0;

    private static final int MARGIN = 3;
    private static final int LINE_SPACING = 11; // in unscaled text units

    // Speed tracking (horizontal blocks per second)
    private static double lastX = Double.NaN;
    private static double lastZ = Double.NaN;
    private static double speedBps = 0;

    private HudRenderer() {
    }

    private static Text styled(String s) {
        return Text.literal(s).setStyle(Style.EMPTY.withFont(new StyleSpriteSource.Font(FONT_ID)));
    }

    /** Called every client tick to update the speed measurement. */
    public static void tick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null) {
            lastX = Double.NaN;
            lastZ = Double.NaN;
            speedBps = 0;
            return;
        }
        double x = player.getX();
        double z = player.getZ();
        if (!Double.isNaN(lastX)) {
            double dx = x - lastX;
            double dz = z - lastZ;
            speedBps = Math.sqrt(dx * dx + dz * dz) * 20.0; // 20 ticks per second
        }
        lastX = x;
        lastZ = z;
    }

    public static void render(DrawContext context, boolean hudEnabled) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!hudEnabled || client.player == null || client.options.hudHidden) {
            return;
        }

        double guiScale = client.getWindow().getScaleFactor();
        float scale = TEXT_SCALE;
        if (guiScale > 0) {
            scale *= (float) (REFERENCE_GUI_SCALE / guiScale);
        }

        TextRenderer tr = client.textRenderer;

        context.getMatrices().pushMatrix();
        context.getMatrices().scale(scale, scale);

        // Everything below is in "scaled" coordinates: divide screen
        // positions by `scale` so things land where we expect on screen.
        int screenWidthScaled = Math.round(context.getScaledWindowWidth() / scale);
        int margin = Math.round(MARGIN / scale);

        // ---- Top-left info block --------------------------------------
        List<String> lines = new ArrayList<>();
        lines.add("Blind Client 1.21.11");
        lines.add("FPS: " + client.getCurrentFps());

        float tps = TpsTracker.getTps();
        lines.add("TPS: " + (tps < 0 ? "--" : String.format("%.1f", tps)));

        lines.add("Ping: " + getPing(client));
        lines.add("Speed: " + String.format("%.1f", speedBps));

        int y = margin;
        for (String line : lines) {
            context.drawTextWithShadow(tr, styled(line), margin, y, WHITE);
            y += LINE_SPACING;
        }

        // ---- Top-right active module list -----------------------------
        List<String> active = new ArrayList<>();
        for (Category category : ClickGuiState.getCategories()) {
            for (Module module : category.getModules()) {
                if (module.isEnabled()) {
                    active.add(module.getName());
                }
            }
        }
        active.sort((a, b) -> tr.getWidth(styled(b)) - tr.getWidth(styled(a)));

        y = margin;
        for (String name : active) {
            int w = tr.getWidth(styled(name));
            context.drawTextWithShadow(tr, styled(name), screenWidthScaled - margin - w, y, WHITE);
            y += LINE_SPACING;
        }

        context.getMatrices().popMatrix();
    }

    private static int getPing(MinecraftClient client) {
        if (client.getNetworkHandler() == null || client.player == null) {
            return 0;
        }
        PlayerListEntry entry = client.getNetworkHandler().getPlayerListEntry(client.player.getUuid());
        return entry != null ? entry.getLatency() : 0;
    }
}
