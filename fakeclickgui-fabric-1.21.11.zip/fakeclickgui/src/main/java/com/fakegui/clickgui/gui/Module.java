package com.fakegui.clickgui.gui;

/**
 * Purely cosmetic "module" entry. Toggling it only flips a boolean and
 * changes the color of its indicator dot - it has no effect whatsoever
 * on the actual game, except for the handful explicitly made real
 * (see ClickGuiState / FakeClickGuiClient for which ones).
 */
public class Module {
    private final String name;
    private final String description;
    private boolean enabled;

    // Optional keybind (GLFW key code), -1 = unbound. Lets the module be
    // toggled while the GUI is closed.
    private int keyBind = -1;
    private boolean heldLastTick = false;

    // Optional free-text setting (null = module has no text setting).
    // Used by Chat Macro for the message to send.
    private String textSetting = null;

    public String getTextSetting() {
        return textSetting;
    }

    public void setTextSetting(String textSetting) {
        this.textSetting = textSetting;
    }

    public boolean hasTextSetting() {
        return textSetting != null;
    }

    public Module(String name, String description) {
        this(name, description, false);
    }

    public Module(String name, String description, boolean enabled) {
        this.name = name;
        this.description = description;
        this.enabled = enabled;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void toggle() {
        enabled = !enabled;
    }

    public int getKeyBind() {
        return keyBind;
    }

    public void setKeyBind(int keyBind) {
        this.keyBind = keyBind;
        this.bindIsMouse = false;
    }

    // ---- Bind options (shown in the module settings screen) -----------
    // When true, keyBind holds a GLFW mouse button index instead of a key code.
    private boolean bindIsMouse = false;
    private boolean toggleOnRelease = false;
    private boolean chatFeedback = true;

    public void setMouseBind(int mouseButton) {
        this.keyBind = mouseButton;
        this.bindIsMouse = true;
    }

    public void clearBind() {
        this.keyBind = -1;
        this.bindIsMouse = false;
    }

    public boolean isBindMouse() {
        return bindIsMouse;
    }

    public boolean isToggleOnRelease() {
        return toggleOnRelease;
    }

    public void setToggleOnRelease(boolean toggleOnRelease) {
        this.toggleOnRelease = toggleOnRelease;
    }

    public boolean isChatFeedback() {
        return chatFeedback;
    }

    public void setChatFeedback(boolean chatFeedback) {
        this.chatFeedback = chatFeedback;
    }

    public boolean isHeldLastTick() {
        return heldLastTick;
    }

    public void setHeldLastTick(boolean heldLastTick) {
        this.heldLastTick = heldLastTick;
    }
}

