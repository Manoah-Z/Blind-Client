package com.fakegui.clickgui.reconnect;

import com.fakegui.clickgui.gui.ClickGuiState;
import com.fakegui.clickgui.gui.Module;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.DisconnectedScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.text.Text;

import java.util.List;

/**
 * Meteor-style disconnect screen extras.
 *
 * When the vanilla "Disconnected" screen appears (kick, server crash,
 * timeout...), three buttons are added under the vanilla one:
 *   - Reconnect            (shows the countdown while auto-reconnect runs)
 *   - Auto Reconnect: ON/OFF
 *   - Main Menu
 *
 * The auto-reconnect countdown only runs while that disconnect screen is
 * actually on screen, so quitting a server voluntarily never triggers it,
 * and leaving the screen (e.g. pressing "Back to server list") cancels it.
 */
public final class ReconnectHandler {

    private static final int RECONNECT_DELAY_TICKS = 100; // 5 seconds
    private static final int BUTTON_WIDTH = 200;
    private static final int BUTTON_HEIGHT = 20;
    private static final int BUTTON_GAP = 4;

    private static ServerInfo lastServerInfo = null;
    private static int countdownTicks = -1;
    private static Screen disconnectScreen = null;
    private static ButtonWidget reconnectButton = null;
    private static ButtonWidget toggleButton = null;

    private ReconnectHandler() {
    }

    public static void register() {
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            lastServerInfo = client.getCurrentServerEntry();
            countdownTicks = -1;
        });

        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof DisconnectedScreen) {
                onDisconnectScreenInit(client, screen);
            }
        });
    }

    private static void onDisconnectScreenInit(MinecraftClient client, Screen screen) {
        // init() also runs again on window resize - only start a new
        // countdown the first time we see this particular screen.
        boolean firstTimeSeeingThisScreen = screen != disconnectScreen;
        disconnectScreen = screen;

        List<ClickableWidget> buttons = Screens.getButtons(screen);

        // Place our buttons right under the lowest existing (vanilla) button.
        int centerX = screen.width / 2;
        int y = screen.height / 2;
        for (ClickableWidget widget : buttons) {
            centerX = widget.getX() + widget.getWidth() / 2;
            y = Math.max(y, widget.getY() + widget.getHeight());
        }
        int x = centerX - BUTTON_WIDTH / 2;
        y += BUTTON_GAP;

        reconnectButton = ButtonWidget.builder(Text.literal("Reconnect"), b -> reconnectNow(client))
                .dimensions(x, y, BUTTON_WIDTH, BUTTON_HEIGHT)
                .build();
        reconnectButton.active = lastServerInfo != null;
        buttons.add(reconnectButton);
        y += BUTTON_HEIGHT + BUTTON_GAP;

        toggleButton = ButtonWidget.builder(toggleLabel(), b -> toggleAutoReconnect())
                .dimensions(x, y, BUTTON_WIDTH, BUTTON_HEIGHT)
                .build();
        buttons.add(toggleButton);
        y += BUTTON_HEIGHT + BUTTON_GAP;

        buttons.add(ButtonWidget.builder(Text.literal("Main Menu"), b -> {
                    countdownTicks = -1;
                    client.setScreen(new TitleScreen());
                })
                .dimensions(x, y, BUTTON_WIDTH, BUTTON_HEIGHT)
                .build());

        if (firstTimeSeeingThisScreen) {
            countdownTicks = (isAutoReconnectEnabled() && lastServerInfo != null) ? RECONNECT_DELAY_TICKS : -1;
        }
        refreshLabels();
    }

    /** Called every client tick. */
    public static void tick(MinecraftClient client) {
        if (countdownTicks < 0) {
            return;
        }
        // Left the disconnect screen (back button, main menu...) -> cancel.
        if (client.currentScreen == null || client.currentScreen != disconnectScreen) {
            countdownTicks = -1;
            return;
        }
        countdownTicks--;
        refreshLabels();
        if (countdownTicks <= 0) {
            reconnectNow(client);
        }
    }

    private static void reconnectNow(MinecraftClient client) {
        countdownTicks = -1;
        if (lastServerInfo == null) {
            return;
        }
        ConnectScreen.connect(
                new MultiplayerScreen(new TitleScreen()),
                client,
                ServerAddress.parse(lastServerInfo.address),
                lastServerInfo,
                false,
                null
        );
    }

    private static void toggleAutoReconnect() {
        Module module = findAutoReconnect();
        if (module == null) {
            return;
        }
        module.toggle();
        if (module.isEnabled() && lastServerInfo != null) {
            countdownTicks = RECONNECT_DELAY_TICKS;
        } else {
            countdownTicks = -1;
        }
        refreshLabels();
    }

    private static void refreshLabels() {
        if (reconnectButton != null) {
            if (countdownTicks > 0) {
                reconnectButton.setMessage(Text.literal(
                        String.format("Reconnect (%.1fs)", countdownTicks / 20.0)));
            } else {
                reconnectButton.setMessage(Text.literal("Reconnect"));
            }
        }
        if (toggleButton != null) {
            toggleButton.setMessage(toggleLabel());
        }
    }

    private static Text toggleLabel() {
        return Text.literal("Auto Reconnect: " + (isAutoReconnectEnabled() ? "ON" : "OFF"));
    }

    private static boolean isAutoReconnectEnabled() {
        Module module = findAutoReconnect();
        return module != null && module.isEnabled();
    }

    private static Module findAutoReconnect() {
        for (var category : ClickGuiState.getCategories()) {
            for (Module module : category.getModules()) {
                if (module.getName().equals("Auto Reconnect")) {
                    return module;
                }
            }
        }
        return null;
    }
}
