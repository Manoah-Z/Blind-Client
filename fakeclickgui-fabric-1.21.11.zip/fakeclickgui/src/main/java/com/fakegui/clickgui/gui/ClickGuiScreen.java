package com.fakegui.clickgui.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Style;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * A fully cosmetic "Click GUI" screen styled after typical cheat-client
 * interfaces. Every toggle here is fake: clicking a module only changes
 * its own displayed color, nothing else. It does not read or modify any
 * game state, inject packets, or alter rendering outside of this menu.
 *
 * Panels can be dragged by their header, collapsed/expanded with a small
 * "-"/"+" button (animated), and there's a live Search panel that filters
 * modules across every category as you type. All of that state is kept
 * in ClickGuiState, so it survives closing and reopening this screen.
 */
public class ClickGuiScreen extends Screen {

    // ---- Theme -------------------------------------------------------
    private static final int PANEL_BG = 0xE6141520;
    private static final int HEADER_BG = 0xFF1B1D29;
    private static final int HEADER_BG_HOVER = 0xFF232633;
    private static final int ROW_HOVER = 0x33FFFFFF;
    private static final int TITLE_COLOR = Theme.ACCENT;
    private static final int TEXT_COLOR = 0xFFC9CDD6;
    private static final int TEXT_COLOR_ON = Theme.ACCENT_LIGHT;
    private static final int TEXT_COLOR_PLACEHOLDER = 0xFF6B6F7A;
    private static final int DOT_OFF = 0xFF3C4050;
    private static final int DOT_ON = Theme.ACCENT;
    private static final int BORDER_COLOR = 0x552F3140;
    private static final int TOGGLE_BOX_COLOR = 0x40FFFFFF;
    private static final int LEFT_BAR_COLOR = Theme.ACCENT;
    private static final int SEARCH_BOX_BG = 0xFF1B1D29;
    private static final int SEARCH_BOX_BG_FOCUSED = 0xFF262B3A;
    private static final int POPUP_BG = 0xF0141520;
    private static final int POPUP_BORDER = Theme.ACCENT;
    private static final int POPUP_WIDTH = 190;
    private static final int POPUP_PADDING = 8;
    private static final int LINE_HEIGHT = 10;

    private static final int PANEL_WIDTH = 148;
    private static final int HEADER_HEIGHT = 18;
    private static final int ROW_HEIGHT = 16;
    private static final int TOGGLE_BOX_SIZE = 12;
    private static final int ICON_SIZE = 8;
    private static final int ICON_GAP = 4;
    private static final int SEARCH_BOX_HEIGHT = 16;
    private static final int MAX_SEARCH_RESULTS = 10;
    private static final float ANIMATION_SPEED = 8f; // openAmount units per second

    // Custom bundled font (MinecraftTen), shipped as a mod resource.
    // See assets/fakeclickgui/font/clickgui.json + the .ttf next to it.
    private static final Identifier FONT_ID = Identifier.of("fakeclickgui", "clickgui");

    // The layout below was designed and looks correct at Minecraft's GUI Scale = 2.
    // We compensate for whatever scale the player actually has set so the menu
    // always renders at this same apparent size on screen.
    private static final double REFERENCE_GUI_SCALE = 2.0;

    private final List<Category> categories = ClickGuiState.getCategories();
    private final Category searchPanel = ClickGuiState.getSearchPanel();
    private final List<Category> allPanels = new ArrayList<>();

    private long lastRenderNanos = -1;

    // Drag state
    private Category draggingCategory = null;
    private double dragOffsetX;
    private double dragOffsetY;

    // Search state
    private String searchText = "";
    private boolean searchFocused = false;

    // Right-click info/bind popup state
    private Module infoModule = null;
    private int popupX;
    private int popupY;
    private Module awaitingBindModule = null;
    private Module editingTextModule = null;

    public ClickGuiScreen() {
        super(Text.literal("Blind Client"));
        allPanels.addAll(categories);
        allPanels.add(searchPanel);
    }

    private boolean isSearchPanel(Category category) {
        return category == searchPanel;
    }

    private Text styled(String s) {
        return Text.literal(s).setStyle(Style.EMPTY.withFont(new StyleSpriteSource.Font(FONT_ID)));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime();
        float dt = lastRenderNanos < 0 ? 0f : (now - lastRenderNanos) / 1_000_000_000f;
        lastRenderNanos = now;

        double uiScale = getUiScale();
        int designMouseX = (int) Math.round(mouseX / uiScale);
        int designMouseY = (int) Math.round(mouseY / uiScale);

        context.getMatrices().pushMatrix();
        context.getMatrices().scale((float) uiScale, (float) uiScale);

        for (Category category : allPanels) {
            updateAnimation(category, dt);
            renderPanel(context, category, designMouseX, designMouseY);
        }

        if (infoModule != null) {
            renderInfoPopup(context, infoModule);
        }

        context.getMatrices().popMatrix();
        super.render(context, mouseX, mouseY, delta);
    }

    /**
     * Factor to apply to our own design-space coordinates so the panel
     * renders at the same apparent size regardless of the player's GUI Scale.
     */
    private double getUiScale() {
        double currentGuiScale = MinecraftClient.getInstance().getWindow().getScaleFactor();
        if (currentGuiScale <= 0) {
            return 1.0;
        }
        return REFERENCE_GUI_SCALE / currentGuiScale;
    }

    private void updateAnimation(Category category, float dt) {
        float target = category.isCollapsed() ? 0f : 1f;
        float current = category.getOpenAmount();
        float diff = target - current;
        if (Math.abs(diff) < 0.01f) {
            category.setOpenAmount(target);
            return;
        }
        float step = Math.min(Math.abs(diff), ANIMATION_SPEED * Math.max(dt, 0f));
        category.setOpenAmount(current + Math.signum(diff) * step);
    }

    private List<Module> searchResults() {
        List<Module> results = new ArrayList<>();
        if (searchText.isEmpty()) {
            return results;
        }
        String needle = searchText.toLowerCase();
        for (Category category : categories) {
            for (Module module : category.getModules()) {
                if (module.getName().toLowerCase().contains(needle)) {
                    results.add(module);
                    if (results.size() >= MAX_SEARCH_RESULTS) {
                        return results;
                    }
                }
            }
        }
        return results;
    }

    private int contentHeight(Category category) {
        if (isSearchPanel(category)) {
            return SEARCH_BOX_HEIGHT + 4 + searchResults().size() * ROW_HEIGHT;
        }
        return category.getModules().size() * ROW_HEIGHT;
    }

    private int visibleContentHeight(Category category) {
        return Math.round(contentHeight(category) * category.getOpenAmount());
    }

    private int panelHeight(Category category) {
        int visible = visibleContentHeight(category);
        return HEADER_HEIGHT + visible + (visible > 0 ? 4 : 0);
    }

    private void renderPanel(DrawContext context, Category category, int mouseX, int mouseY) {
        int x = category.getX();
        int y = category.getY();
        int panelHeight = panelHeight(category);
        int visibleContent = visibleContentHeight(category);

        boolean headerHovered = mouseX >= x && mouseX <= x + PANEL_WIDTH
                && mouseY >= y && mouseY < y + HEADER_HEIGHT;

        // Panel background + border
        context.fill(x, y, x + PANEL_WIDTH, y + panelHeight, PANEL_BG);
        context.drawStrokedRectangle(x, y, PANEL_WIDTH, panelHeight, BORDER_COLOR);

        // Header (draggable area)
        context.fill(x, y, x + PANEL_WIDTH, y + HEADER_HEIGHT, headerHovered ? HEADER_BG_HOVER : HEADER_BG);

        drawCategoryIcon(context, category.getTitle(), x + 6, y + (HEADER_HEIGHT - ICON_SIZE) / 2, TITLE_COLOR);
        context.drawTextWithShadow(this.textRenderer, styled(category.getTitle().toUpperCase()),
                x + 6 + ICON_SIZE + ICON_GAP, y + 6, TITLE_COLOR);

        // Collapse/expand toggle box
        int boxX = x + PANEL_WIDTH - TOGGLE_BOX_SIZE - 4;
        int boxY = y + (HEADER_HEIGHT - TOGGLE_BOX_SIZE) / 2;
        boolean boxHovered = mouseX >= boxX && mouseX <= boxX + TOGGLE_BOX_SIZE
                && mouseY >= boxY && mouseY <= boxY + TOGGLE_BOX_SIZE;
        context.fill(boxX, boxY, boxX + TOGGLE_BOX_SIZE, boxY + TOGGLE_BOX_SIZE,
                boxHovered ? 0x80FFFFFF : TOGGLE_BOX_COLOR);
        String glyph = category.isCollapsed() ? "+" : "-";
        context.drawTextWithShadow(this.textRenderer, styled(glyph),
                boxX + (TOGGLE_BOX_SIZE / 2) - 2, boxY + 2, TITLE_COLOR);

        if (visibleContent <= 0) {
            return;
        }

        // Content, clipped to the currently visible (animated) height.
        // enableScissor already respects the matrix scale we pushed in
        // render(), same as fill()/drawTextWithShadow() do - so we pass the
        // same raw local coordinates here, with no extra multiplication.
        context.enableScissor(
                x,
                y + HEADER_HEIGHT,
                x + PANEL_WIDTH,
                y + HEADER_HEIGHT + visibleContent);

        if (isSearchPanel(category)) {
            renderSearchContent(context, x, y, mouseX, mouseY);
        } else {
            renderModuleRows(context, category, x, y, mouseX, mouseY);
        }

        context.disableScissor();
    }

    private void renderModuleRows(DrawContext context, Category category, int x, int y, int mouseX, int mouseY) {
        int rowY = y + HEADER_HEIGHT + 2;
        for (Module module : category.getModules()) {
            boolean hovered = category.getOpenAmount() >= 0.99f
                    && mouseX >= x && mouseX <= x + PANEL_WIDTH
                    && mouseY >= rowY && mouseY < rowY + ROW_HEIGHT;

            if (hovered) {
                context.fill(x + 2, rowY, x + PANEL_WIDTH - 2, rowY + ROW_HEIGHT, ROW_HOVER);
            }

            if (module.isEnabled()) {
                context.fill(x, rowY, x + 2, rowY + ROW_HEIGHT, LEFT_BAR_COLOR);
            }

            int textColor = module.isEnabled() ? TEXT_COLOR_ON : TEXT_COLOR;
            context.drawTextWithShadow(this.textRenderer, styled(module.getName()),
                    x + 8, rowY + 4, textColor);

            if (module.getKeyBind() != -1) {
                String bindLabel = Theme.bindName(module);
                int bindTextWidth = this.textRenderer.getWidth(styled(bindLabel));
                context.drawTextWithShadow(this.textRenderer, styled(bindLabel),
                        x + PANEL_WIDTH - 20 - bindTextWidth, rowY + 4, TEXT_COLOR_PLACEHOLDER);
            }

            int dotX = x + PANEL_WIDTH - 14;
            int dotY = rowY + ROW_HEIGHT / 2;
            int dotColor = module.isEnabled() ? DOT_ON : DOT_OFF;
            context.fill(dotX - 3, dotY - 3, dotX + 3, dotY + 3, dotColor);

            rowY += ROW_HEIGHT;
        }
    }

    private void renderSearchContent(DrawContext context, int x, int y, int mouseX, int mouseY) {
        int boxY = y + HEADER_HEIGHT + 2;

        context.fill(x + 4, boxY, x + PANEL_WIDTH - 4, boxY + SEARCH_BOX_HEIGHT,
                searchFocused ? SEARCH_BOX_BG_FOCUSED : SEARCH_BOX_BG);
        context.drawStrokedRectangle(x + 4, boxY, PANEL_WIDTH - 8, SEARCH_BOX_HEIGHT,
                searchFocused ? TITLE_COLOR : BORDER_COLOR);

        drawCategoryIcon(context, "Search", x + 8, boxY + (SEARCH_BOX_HEIGHT - ICON_SIZE) / 2, TEXT_COLOR_PLACEHOLDER);

        String shown = searchText.isEmpty() ? "Search modules" : searchText;
        int textColor = searchText.isEmpty() ? TEXT_COLOR_PLACEHOLDER : TEXT_COLOR;
        int textX = x + 8 + ICON_SIZE + ICON_GAP;
        context.drawTextWithShadow(this.textRenderer, styled(shown), textX, boxY + 4, textColor);

        if (searchFocused) {
            int caretX = textX + this.textRenderer.getWidth(styled(searchText));
            context.fill(caretX + 1, boxY + 3, caretX + 2, boxY + SEARCH_BOX_HEIGHT - 3, 0xFFFFFFFF);
        }

        List<Module> results = searchResults();
        int rowY = boxY + SEARCH_BOX_HEIGHT + 4;
        for (Module module : results) {
            boolean hovered = mouseX >= x && mouseX <= x + PANEL_WIDTH
                    && mouseY >= rowY && mouseY < rowY + ROW_HEIGHT;

            if (hovered) {
                context.fill(x + 2, rowY, x + PANEL_WIDTH - 2, rowY + ROW_HEIGHT, ROW_HOVER);
            }

            if (module.isEnabled()) {
                context.fill(x, rowY, x + 2, rowY + ROW_HEIGHT, LEFT_BAR_COLOR);
            }

            int textColor2 = module.isEnabled() ? TEXT_COLOR_ON : TEXT_COLOR;
            context.drawTextWithShadow(this.textRenderer, styled(module.getName()), x + 8, rowY + 4, textColor2);

            if (module.getKeyBind() != -1) {
                String bindLabel = Theme.bindName(module);
                int bindTextWidth = this.textRenderer.getWidth(styled(bindLabel));
                context.drawTextWithShadow(this.textRenderer, styled(bindLabel),
                        x + PANEL_WIDTH - 20 - bindTextWidth, rowY + 4, TEXT_COLOR_PLACEHOLDER);
            }

            int dotX = x + PANEL_WIDTH - 14;
            int dotY = rowY + ROW_HEIGHT / 2;
            context.fill(dotX - 3, dotY - 3, dotX + 3, dotY + 3, module.isEnabled() ? DOT_ON : DOT_OFF);

            rowY += ROW_HEIGHT;
        }
    }

    private List<String> wrapText(String text, int maxWidth) {
        List<String> lines = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String word : text.split(" ")) {
            String candidate = line.isEmpty() ? word : line + " " + word;
            if (this.textRenderer.getWidth(styled(candidate)) > maxWidth && !line.isEmpty()) {
                lines.add(line.toString());
                line = new StringBuilder(word);
            } else {
                line = new StringBuilder(candidate);
            }
        }
        if (!line.isEmpty()) {
            lines.add(line.toString());
        }
        return lines;
    }

    private String keyName(int keyCode) {
        return switch (keyCode) {
            case GLFW.GLFW_KEY_SPACE -> "SPACE";
            case GLFW.GLFW_KEY_LEFT_SHIFT -> "L-SHIFT";
            case GLFW.GLFW_KEY_RIGHT_SHIFT -> "R-SHIFT";
            case GLFW.GLFW_KEY_LEFT_CONTROL -> "L-CTRL";
            case GLFW.GLFW_KEY_RIGHT_CONTROL -> "R-CTRL";
            case GLFW.GLFW_KEY_LEFT_ALT -> "L-ALT";
            case GLFW.GLFW_KEY_RIGHT_ALT -> "R-ALT";
            case GLFW.GLFW_KEY_TAB -> "TAB";
            case GLFW.GLFW_KEY_CAPS_LOCK -> "CAPS";
            case GLFW.GLFW_KEY_ENTER, GLFW.GLFW_KEY_KP_ENTER -> "ENTER";
            case GLFW.GLFW_KEY_UP -> "UP";
            case GLFW.GLFW_KEY_DOWN -> "DOWN";
            case GLFW.GLFW_KEY_LEFT -> "LEFT";
            case GLFW.GLFW_KEY_RIGHT -> "RIGHT";
            default -> {
                String glfwName = GLFW.glfwGetKeyName(keyCode, 0);
                yield glfwName != null ? glfwName.toUpperCase() : "KEY " + keyCode;
            }
        };
    }

    /**
     * Computes the popup's line list and pixel height together, so render
     * and click-handling always agree on its size/position.
     */
    private List<String> popupBodyLines(Module module) {
        return wrapText(module.getDescription(), POPUP_WIDTH - POPUP_PADDING * 2);
    }

    private int bindRowY(Module module) {
        int lines = popupBodyLines(module).size();
        return popupY + POPUP_PADDING + LINE_HEIGHT + 4 + lines * LINE_HEIGHT + 6;
    }

    /** Row holding the editable text setting (only for modules that have one). */
    private int textRowY(Module module) {
        return bindRowY(module) + LINE_HEIGHT + 4;
    }

    private int popupHeight(Module module) {
        int bottom = bindRowY(module) + LINE_HEIGHT;
        if (module.hasTextSetting()) {
            bottom = textRowY(module) + LINE_HEIGHT + 2;
        }
        return bottom - popupY + POPUP_PADDING;
    }

    private void renderInfoPopup(DrawContext context, Module module) {
        int height = popupHeight(module);
        int x = popupX;
        int y = popupY;

        context.fill(x, y, x + POPUP_WIDTH, y + height, POPUP_BG);
        context.drawStrokedRectangle(x, y, POPUP_WIDTH, height, POPUP_BORDER);

        int textY = y + POPUP_PADDING;
        context.drawTextWithShadow(this.textRenderer, styled(module.getName()), x + POPUP_PADDING, textY, TITLE_COLOR);
        textY += LINE_HEIGHT + 4;

        for (String line : popupBodyLines(module)) {
            context.drawTextWithShadow(this.textRenderer, styled(line), x + POPUP_PADDING, textY, TEXT_COLOR);
            textY += LINE_HEIGHT;
        }

        textY += 6;
        boolean awaiting = awaitingBindModule == module;
        String bindLabel = awaiting ? "Press a key..." : (module.getKeyBind() == -1 ? "Click to set" : Theme.bindName(module));
        context.drawTextWithShadow(this.textRenderer, styled("Bind: " + bindLabel), x + POPUP_PADDING, textY,
                awaiting ? TITLE_COLOR : TEXT_COLOR_ON);

        if (module.hasTextSetting()) {
            boolean editing = editingTextModule == module;
            int rowY = textRowY(module);
            int boxLeft = x + POPUP_PADDING - 2;
            int boxRight = x + POPUP_WIDTH - POPUP_PADDING + 2;
            context.fill(boxLeft, rowY - 2, boxRight, rowY + LINE_HEIGHT, editing ? SEARCH_BOX_BG_FOCUSED : SEARCH_BOX_BG);
            context.drawStrokedRectangle(boxLeft, rowY - 2, boxRight - boxLeft, LINE_HEIGHT + 2,
                    editing ? TITLE_COLOR : BORDER_COLOR);

            String prefix = "Message: ";
            String value = module.getTextSetting();
            int maxValueWidth = (boxRight - 4) - (x + POPUP_PADDING) - this.textRenderer.getWidth(styled(prefix)) - 3;
            // Show the end of the text if it's too long to fit.
            String shown = value;
            while (!shown.isEmpty() && this.textRenderer.getWidth(styled(shown)) > maxValueWidth) {
                shown = shown.substring(1);
            }
            String line = prefix + shown;
            context.drawTextWithShadow(this.textRenderer, styled(line), x + POPUP_PADDING, rowY,
                    editing ? TEXT_COLOR : TEXT_COLOR_ON);
            if (editing) {
                int caretX = x + POPUP_PADDING + this.textRenderer.getWidth(styled(line));
                context.fill(caretX + 1, rowY - 1, caretX + 2, rowY + LINE_HEIGHT - 2, 0xFFFFFFFF);
            }
        }
    }

    private boolean isPopupTextRowClick(double mouseX, double mouseY, Module module) {
        if (!module.hasTextSetting()) {
            return false;
        }
        int rowY = textRowY(module);
        return mouseX >= popupX && mouseX <= popupX + POPUP_WIDTH
                && mouseY >= rowY - 2 && mouseY <= rowY + LINE_HEIGHT;
    }

    /**
     * @return true if the click was on the "Bind:" row of the open popup.
     */
    private boolean isPopupBindRowClick(double mouseX, double mouseY, Module module) {
        int bindRowY = bindRowY(module);
        return mouseX >= popupX && mouseX <= popupX + POPUP_WIDTH
                && mouseY >= bindRowY && mouseY <= bindRowY + LINE_HEIGHT;
    }

    private boolean isInsidePopup(double mouseX, double mouseY, Module module) {
        int height = popupHeight(module);
        return mouseX >= popupX && mouseX <= popupX + POPUP_WIDTH
                && mouseY >= popupY && mouseY <= popupY + height;
    }

    /**
     * Small hand-drawn pixel icons (no external image assets needed).
     * Approximate placeholders - send a reference image if you want these
     * matched pixel-for-pixel to a specific design.
     */
    private void drawCategoryIcon(DrawContext context, String title, int ix, int iy, int color) {
        switch (title) {
            case "Combat" -> {
                context.fill(ix + 3, iy, ix + 5, iy + 6, color);       // blade
                context.fill(ix + 1, iy + 5, ix + 7, iy + 6, color);   // guard
                context.fill(ix + 3, iy + 6, ix + 5, iy + 8, color);   // hilt
            }
            case "Misc" -> {
                context.fill(ix + 3, iy, ix + 5, iy + 8, color);       // vertical
                context.fill(ix, iy + 3, ix + 8, iy + 5, color);       // horizontal
            }
            case "Donut" -> context.drawStrokedRectangle(ix, iy, 8, 8, color);
            case "Basefinding" -> {
                context.drawStrokedRectangle(ix + 1, iy + 1, 6, 6, color); // compass ring
                context.fill(ix + 3, iy, ix + 5, iy + 2, color);           // north tick
            }
            case "Render" -> {
                context.fill(ix, iy + 2, ix + 8, iy + 6, color);
                context.fill(ix + 3, iy + 3, ix + 5, iy + 5, PANEL_BG);
            }
            case "Client" -> {
                context.fill(ix + 3, iy, ix + 5, iy + 2, color);
                context.fill(ix, iy + 5, ix + 2, iy + 7, color);
                context.fill(ix + 6, iy + 5, ix + 8, iy + 7, color);
            }
            case "Search" -> {
                context.drawStrokedRectangle(ix, iy, 6, 6, color);
                context.fill(ix + 5, iy + 5, ix + 8, iy + 8, color);
            }
            default -> {
            }
        }
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubleClick) {
        double uiScale = getUiScale();
        double mouseX = click.x() / uiScale;
        double mouseY = click.y() / uiScale;
        int button = click.button();

        // If the info popup is open, its own hit-targets take priority.
        if (infoModule != null) {
            if (isPopupBindRowClick(mouseX, mouseY, infoModule)) {
                editingTextModule = null;
                awaitingBindModule = infoModule;
                return true;
            }
            if (isPopupTextRowClick(mouseX, mouseY, infoModule)) {
                editingTextModule = infoModule;
                return true;
            }
            if (isInsidePopup(mouseX, mouseY, infoModule)) {
                editingTextModule = null;
                return true; // swallow clicks inside the popup body
            }
            infoModule = null; // clicked elsewhere - close it, fall through
            editingTextModule = null;
        }

        searchFocused = false;

        for (Category category : allPanels) {
            int x = category.getX();
            int y = category.getY();

            boolean inHeader = mouseX >= x && mouseX <= x + PANEL_WIDTH
                    && mouseY >= y && mouseY < y + HEADER_HEIGHT;

            if (inHeader) {
                if (button == 0) {
                    int boxX = x + PANEL_WIDTH - TOGGLE_BOX_SIZE - 4;
                    int boxY = y + (HEADER_HEIGHT - TOGGLE_BOX_SIZE) / 2;
                    boolean onToggleBox = mouseX >= boxX && mouseX <= boxX + TOGGLE_BOX_SIZE
                            && mouseY >= boxY && mouseY <= boxY + TOGGLE_BOX_SIZE;

                    if (onToggleBox) {
                        category.toggleCollapsed();
                    } else {
                        draggingCategory = category;
                        dragOffsetX = mouseX - x;
                        dragOffsetY = mouseY - y;
                    }
                }
                return true;
            }

            if (category.getOpenAmount() < 0.99f) {
                continue;
            }

            if (isSearchPanel(category)) {
                int boxY = y + HEADER_HEIGHT + 2;
                boolean inBox = mouseX >= x + 4 && mouseX <= x + PANEL_WIDTH - 4
                        && mouseY >= boxY && mouseY < boxY + SEARCH_BOX_HEIGHT;
                if (inBox) {
                    if (button == 0) {
                        searchFocused = true;
                    }
                    return true;
                }

                int rowY = boxY + SEARCH_BOX_HEIGHT + 4;
                for (Module module : searchResults()) {
                    if (mouseX >= x && mouseX <= x + PANEL_WIDTH
                            && mouseY >= rowY && mouseY < rowY + ROW_HEIGHT) {
                        handleRowClick(module, button, mouseX, mouseY);
                        return true;
                    }
                    rowY += ROW_HEIGHT;
                }
            } else {
                int rowY = y + HEADER_HEIGHT + 2;
                for (Module module : category.getModules()) {
                    if (mouseX >= x && mouseX <= x + PANEL_WIDTH
                            && mouseY >= rowY && mouseY < rowY + ROW_HEIGHT) {
                        handleRowClick(module, button, mouseX, mouseY);
                        return true;
                    }
                    rowY += ROW_HEIGHT;
                }
            }
        }
        return super.mouseClicked(click, doubleClick);
    }

    private void handleRowClick(Module module, int button, double mouseX, double mouseY) {
        if (button == 0) {
            module.toggle();
        } else if (button == 1) {
            // Right-click: open the module's own settings screen. The ClickGUI
            // is hidden while it's open; Escape there comes back here.
            MinecraftClient.getInstance().setScreen(new ModuleScreen(module, this));
        }
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (draggingCategory != null) {
            double uiScale = getUiScale();
            double mouseX = click.x() / uiScale;
            double mouseY = click.y() / uiScale;
            draggingCategory.setX((int) Math.round(mouseX - dragOffsetX));
            draggingCategory.setY((int) Math.round(mouseY - dragOffsetY));
            return true;
        }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        if (draggingCategory != null) {
            draggingCategory = null;
            return true;
        }
        return super.mouseReleased(click);
    }

    @Override
    public boolean charTyped(CharInput input) {
        if (editingTextModule != null) {
            int codepoint = input.codepoint();
            String current = editingTextModule.getTextSetting();
            if (codepoint >= 32 && codepoint != 127 && current.length() < 256) {
                editingTextModule.setTextSetting(current + new String(Character.toChars(codepoint)));
            }
            return true;
        }
        if (searchFocused) {
            int codepoint = input.codepoint();
            // Printable character filter done by hand (control chars like
            // Tab/Enter/Backspace have codepoints below 32, or 127 for DEL).
            if (codepoint >= 32 && codepoint != 127 && searchText.length() < 32) {
                searchText += new String(Character.toChars(codepoint));
            }
            return true;
        }
        return super.charTyped(input);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();

        if (awaitingBindModule != null) {
            if (key == GLFW.GLFW_KEY_ESCAPE) {
                cancelBindListening();
                return true;
            }
            awaitingBindModule.setKeyBind(key);
            awaitingBindModule = null;
            return true;
        }

        if (editingTextModule != null) {
            String current = editingTextModule.getTextSetting();
            if (key == GLFW.GLFW_KEY_BACKSPACE && !current.isEmpty()) {
                editingTextModule.setTextSetting(current.substring(0, current.length() - 1));
            } else if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
                editingTextModule = null;
            }
            return true; // swallow everything else while typing
        }

        if (searchFocused) {
            if (key == GLFW.GLFW_KEY_BACKSPACE && !searchText.isEmpty()) {
                searchText = searchText.substring(0, searchText.length() - 1);
                return true;
            }
            if (key == GLFW.GLFW_KEY_ESCAPE) {
                searchFocused = false;
                return true;
            }
            // Let other keys pass through as "consumed" while the search box
            // is focused, so typing doesn't accidentally close the screen.
            if (key != GLFW.GLFW_KEY_ENTER && key != GLFW.GLFW_KEY_KP_ENTER) {
                return true;
            }
        }
        return super.keyPressed(input);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void close() {
        if (editingTextModule != null) {
            editingTextModule = null;
            return;
        }
        if (awaitingBindModule != null) {
            // Escape was meant to cancel bind-listening, not close the whole menu.
            // We intercept close() directly here since the engine's Escape
            // handling in this version doesn't reliably go through
            // shouldCloseOnEsc()/keyPressed() the way older versions did.
            cancelBindListening();
            return;
        }
        super.close();
    }

    /**
     * Escape while listening for a bind unbinds the module entirely
     * (clears its keybind), rather than restoring the previous key.
     */
    private void cancelBindListening() {
        if (awaitingBindModule != null) {
            awaitingBindModule.setKeyBind(-1);
        }
        awaitingBindModule = null;
    }

    public static void open() {
        MinecraftClient.getInstance().setScreen(new ClickGuiScreen());
    }
}
