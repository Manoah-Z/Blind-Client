package com.fakegui.clickgui.gui;

import java.util.List;

public class Category {
    private final String title;
    private final List<Module> modules;

    // Draggable position (mutable, defaults set by the GUI on first build).
    private int x;
    private int y;

    // Collapse state + animation (0 = fully collapsed, 1 = fully open).
    private boolean collapsed = false;
    private float openAmount = 1f;

    public Category(String title, List<Module> modules) {
        this.title = title;
        this.modules = modules;
    }

    public String getTitle() {
        return title;
    }

    public List<Module> getModules() {
        return modules;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public boolean isCollapsed() {
        return collapsed;
    }

    public void toggleCollapsed() {
        collapsed = !collapsed;
    }

    public float getOpenAmount() {
        return openAmount;
    }

    public void setOpenAmount(float openAmount) {
        this.openAmount = openAmount;
    }
}

