package com.fakegui.clickgui.mixin;

import com.fakegui.clickgui.hud.TpsTracker;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.WorldTimeUpdateS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Feeds TpsTracker. Injected at TAIL so it only runs once, on the main
 * thread (the handler first bounces itself from the network thread to
 * the main thread and aborts the network-thread call).
 *
 * require = 0: if this target ever doesn't match, the game still launches
 * normally and the HUD just shows "--" for TPS instead of crashing.
 */
@Mixin(ClientPlayNetworkHandler.class)
public class ClientPlayNetworkHandlerMixin {

    @Inject(method = "onWorldTimeUpdate", at = @At("TAIL"), require = 0)
    private void fakeclickgui$onTimeUpdate(WorldTimeUpdateS2CPacket packet, CallbackInfo ci) {
        TpsTracker.onTimeUpdate();
    }
}
